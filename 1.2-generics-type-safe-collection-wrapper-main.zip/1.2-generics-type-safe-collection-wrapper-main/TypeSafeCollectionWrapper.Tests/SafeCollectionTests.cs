using Xunit;
using TypeSafeCollectionWrapper;
using TypeSafeCollectionWrapper.Models;

namespace TypeSafeCollectionWrapper.Tests;

public class SafeCollectionTests
{
    private SafeCollection<Customer> GetSampleCollection()
    {
        var collection = new SafeCollection<Customer>();
        collection.Add(new Customer { Id = 1, Name = "Test One" });
        collection.Add(new Customer { Id = 2, Name = "Test Two" });
        return collection;
    }

    [Fact]
    public void Add_ShouldIncreaseCount()
    {
        var collection = new SafeCollection<Customer>();
        collection.Add(new Customer { Id = 1, Name = "Test" });

        Assert.Equal(1, collection.Count);
    }

    [Fact]
    public void GetAll_ShouldReturnAllItems()
    {
        var collection = GetSampleCollection();

        var items = collection.GetAll();

        Assert.Equal(2, items.Count);
    }

    [Fact]
    public void Remove_ShouldDecreaseCount()
    {
        var collection = GetSampleCollection();
        var removed = collection.Remove(new Customer { Id = 1, Name = "Test One" });

        Assert.True(removed);
        Assert.Equal(1, collection.Count);
    }
}
