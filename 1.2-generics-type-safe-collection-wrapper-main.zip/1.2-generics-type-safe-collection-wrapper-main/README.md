# Type-safe Collection Wrapper

## Task Title:
Type-safe Generic Collection Wrapper for Business Models

## Description:
You�ve been assigned to build an internal utility library that wraps generic `List<T>` operations in a controlled and reusable structure. The idea is to standardize how collections are used across business domains such as `Customer`, `Product`, etc., while enforcing type safety and providing extension points for validation or transformation logic later on.

## Topics Covered:
- Generic Classes
- Encapsulation of Collections
- Generic Constraints (e.g., interface-based)
- Type Reusability

## Objective:
Create a generic collection wrapper class named `SafeCollection<T>` that internally uses `List<T>` to manage items, allowing controlled access via `Add`, `Remove`, `Count`, and `GetAll` methods.

## Instructions:
- Fork the repository.
- Complete the logic in the provided boilerplate code.
- Make sure all the unit tests pass.
- Do not change the test code.
- Submit your solution with a pull request or upload as required.