﻿using System;
using TypeSafeCollectionWrapper.Models;

namespace TypeSafeCollectionWrapper;

public class Program
{
    public static void Main()
    {
        var customers = new SafeCollection<Customer>();
        customers.Add(new Customer { Id = 1, Name = "John Doe" });
        customers.Add(new Customer { Id = 2, Name = "Jane Smith" });

        Console.WriteLine($"Total Customers: {customers.Count}");
        foreach (var customer in customers.GetAll())
        {
            Console.WriteLine($"Customer: {customer.Id}, {customer.Name}");
        }
    }
}