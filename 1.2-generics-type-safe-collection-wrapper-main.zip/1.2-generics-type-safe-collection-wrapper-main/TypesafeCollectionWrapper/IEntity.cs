﻿namespace TypeSafeCollectionWrapper
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}