﻿using System.Collections.Generic;
using System.Security.Principal;

namespace TypeSafeCollectionWrapper;

public class SafeCollection<T> where T : IEntity
{
    private readonly List<T> _items = new();

    public void Add(T item)
    {
        // TODO: Implement add logic
    }

    public bool Remove(T item)
    {
        // TODO: Implement remove logic
        return false;
    }

    public int Count => _items.Count; // Already implemented

    public IReadOnlyList<T> GetAll()
    {
        // TODO: Return all items as readonly list
        return new List<T>();
    }
}