# ASP.NET MVC Advanced Real-Time Project

## Task Title
Online Course Management System Using ASP.NET MVC with Onion Architecture

## Description
You are tasked with developing a real-world web application called **Online Course Management System** that allows administrators to manage courses, instructors to publish and manage content, and students to enroll in and complete courses. This application must be built using ASP.NET MVC and follow clean architectural principles using Onion Architecture. The system must leverage dependency injection, support various data access patterns, maintain application state appropriately, and follow robust configuration and error-handling practices.

## Topics Covered
- ASP.NET MVC Architecture (Models, Views, Controllers)
- Onion Architecture (Separation of Concerns)
- Routing (Attribute & Convention-Based)
- Controllers & Action Methods
- Strongly-Typed Views, ViewModels
- HTML Helpers and Tag Helpers
- Data Access using EF Core / ADO.NET / Dapper (any or mix)
- Dependency Injection (Built-in DI Container)
- State Management (TempData, ViewData, Session)
- Configuration (appsettings.json, IOptions pattern)
- Filters (Authorization, Exception, Action)
- Error Handling (Try-Catch, Global Filters, Custom Error Pages)

## Objective
By completing this project, learners will:
- Develop a scalable and layered MVC web application.
- Apply best practices with Onion Architecture.
- Build robust, testable, and maintainable code.
- Demonstrate end-to-end understanding of ASP.NET MVC framework and its integration with data access technologies and middleware features.

## Instructions
- Fork this repository.
- Scaffold the base folder structure under `src/OnlineCourseManagementSystem/`
- Complete the application logic for each layer as defined.
- Create at least 3 modules: Course Management, Instructor Management, and Student Enrollment.
- Include error-handling and state management across the modules.
- Make sure the routing, views, controllers, and models reflect clean MVC design.
- Populate dummy data where applicable.
- Submit the completed solution via a pull request or zip upload as required.

---

## Folder Structure
```
OnlineCourseManagementSystem/
├── src/
│   └── OnlineCourseManagementSystem/
│       ├── OnlineCourseManagementSystem.Web/            # MVC Layer (Controllers, Views)
│       ├── OnlineCourseManagementSystem.Application/    # Application Services & DTOs
│       ├── OnlineCourseManagementSystem.Domain/         # Entities & Interfaces
│       ├── OnlineCourseManagementSystem.Infrastructure/ # Data Access Layer (EF Core / ADO.NET / Dapper)
│       └── OnlineCourseManagementSystem.Core/           # Cross-cutting concerns (logging, helpers)
├── README.md
```

---

## Requirements Summary
### 1. MVC Architecture
- Use models to represent Course, Instructor, and Student.
- Use controllers to handle CRUD operations for each entity.
- Create views using Razor with strongly-typed ViewModels.

### 2. Onion Architecture
- Keep each layer decoupled.
- Application layer depends only on domain.
- Infrastructure implements interfaces defined in Domain layer.

### 3. Routing
- Use conventional routing in `Program.cs` or `Startup.cs`.
- Apply attribute routing for specific controller actions.

### 4. HTML and Tag Helpers
- Use Razor syntax to bind ViewModels.
- Use `Html.TextBoxFor`, `Html.DropDownListFor`, etc.
- Use tag helpers for forms and validation messages.

### 5. Data Access
- Implement repository pattern using EF Core.
- Optionally, use ADO.NET or Dapper in Infrastructure layer.

### 6. Dependency Injection
- Register services and repositories using built-in DI container in Program.cs.

### 7. State Management
- Demonstrate usage of TempData, ViewData, and Session in workflows (e.g., Enrollment Confirmation).

### 8. Configuration
- Read settings from appsettings.json.
- Use the `IOptions<T>` pattern to bind to POCO classes.

### 9. Error Handling
- Global exception filter.
- Try-catch blocks.
- Custom error pages.

### 10. Filters
- Use AuthorizationFilter for admin-only sections.
- Use ActionFilter to log actions.
- Use ExceptionFilter for centralized error handling.

---

Start building the solution structure and complete modules step-by-step.

You can begin with `CourseController`, `InstructorController`, and `StudentController` with views and proceed to application service implementations.

Happy coding!

---