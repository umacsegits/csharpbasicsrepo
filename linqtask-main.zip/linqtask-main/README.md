# LINQ Analytics Dashboard with LINQ Internals

## Task Title
Build an Analytics Dashboard using LINQ and LINQ Internals

## Description
You are developing a sales analytics dashboard that processes transaction data in-memory using LINQ. Your job is to generate various sales reports using LINQ queries. These include summaries by category, filtering by thresholds, grouping and aggregation, and transforming raw records into simplified DTOs for reporting. The solution should be extensible and efficient.

## Topics Covered
- LINQ Queries (Query and Method Syntax)
- Deferred vs Immediate Execution
- Projection (Select, SelectMany)
- Filtering (Where)
- Grouping and Aggregation
- Anonymous Types and DTO Projection
- IEnumerable vs IQueryable distinctions (internally)

## Objective
The learner will develop a reusable, real-world analytics engine using LINQ on a sample dataset and understand LINQ's internal execution concepts.

## Instructions
- Fork the repository.
- Complete the logic in the provided boilerplate code.
- Make sure all the unit tests pass.
- Do not change the test code.
- Submit your solution with a pull request or upload as required.
