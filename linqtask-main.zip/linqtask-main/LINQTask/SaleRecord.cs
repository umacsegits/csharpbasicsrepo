﻿namespace LinqInternalsTask.Models;

public class SaleRecord
{
    public string Region { get; set; } = string.Empty;
    public string Product { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }

    public decimal Total => Quantity * UnitPrice;
}

public static class DummySalesData
{
    public static List<SaleRecord> GetSampleData()
    {
        return new List<SaleRecord>
        {
            new SaleRecord { Region = "North", Product = "Pen", Category = "Stationery", Quantity = 100, UnitPrice = 2.5m, Date = DateTime.Today.AddDays(-2) },
            new SaleRecord { Region = "North", Product = "Notebook", Category = "Stationery", Quantity = 50, UnitPrice = 5.5m, Date = DateTime.Today.AddDays(-1) },
            new SaleRecord { Region = "South", Product = "Charger", Category = "Electronics", Quantity = 30, UnitPrice = 20m, Date = DateTime.Today },
            // Add more dummy records as needed
        };
    }
}