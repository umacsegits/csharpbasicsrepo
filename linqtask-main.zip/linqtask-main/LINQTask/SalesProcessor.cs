﻿using LinqInternalsTask.Models;

namespace LinqInternalsTask.Services;

public class SalesProcessor
{
    public IEnumerable<string> GetTopSellingCategories(List<SaleRecord> data, int topN)
    {
        // TODO: Use LINQ to get top N categories by total revenue
        throw new NotImplementedException();
    }

    public decimal GetTotalSalesByRegion(List<SaleRecord> data, string region)
    {
        // TODO: Use LINQ to filter by region and calculate total sales
        throw new NotImplementedException();
    }

    public IEnumerable<(string Category, decimal Revenue)> GetRevenueByCategory(List<SaleRecord> data)
    {
        // TODO: Use GroupBy and Sum to aggregate revenue
        throw new NotImplementedException();
    }

    public IEnumerable<string> GetLowPerformingProducts(List<SaleRecord> data, decimal revenueThreshold)
    {
        // TODO: Filter products with total revenue below threshold
        throw new NotImplementedException();
    }

    public IEnumerable<string> GetDistinctRegions(List<SaleRecord> data)
    {
        // TODO: Return distinct list of regions
        throw new NotImplementedException();
    }
}