﻿using LinqInternalsTask.Models;
using LinqInternalsTask.Services;

namespace LinqInternalsTask;

class Program
{
    static void Main(string[] args)
    {
        var data = DummySalesData.GetSampleData();
        var processor = new SalesProcessor();

        // TODO: Call methods and print analytics outputs using LINQ queries
    }
}