using LinqInternalsTask.Models;
using LinqInternalsTask.Services;
using Xunit;

namespace LinqInternalsTask.Tests;

public class SalesProcessorTests
{
    private readonly List<SaleRecord> _data = DummySalesData.GetSampleData();
    private readonly SalesProcessor _processor = new();

    [Fact]
    public void ShouldReturnTopCategories()
    {
        var result = _processor.GetTopSellingCategories(_data, 1);
        Assert.NotNull(result);
        Assert.Single(result);
    }

    [Fact]
    public void ShouldReturnCorrectTotalForRegion()
    {
        var result = _processor.GetTotalSalesByRegion(_data, "North");
        Assert.True(result > 0);
    }

    [Fact]
    public void ShouldGroupRevenueByCategory()
    {
        var result = _processor.GetRevenueByCategory(_data);
        Assert.Contains(result, r => r.Category == "Stationery");
    }

    [Fact]
    public void ShouldFindLowPerformers()
    {
        var result = _processor.GetLowPerformingProducts(_data, 300);
        Assert.NotNull(result);
    }

    [Fact]
    public void ShouldReturnDistinctRegions()
    {
        var result = _processor.GetDistinctRegions(_data);
        Assert.Contains("North", result);
        Assert.Contains("South", result);
    }
}
