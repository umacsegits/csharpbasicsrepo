﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace CSharpBasics.Core
{
    public class Collections<T> : IEnumerable<T>
    {
        private T[] _items;
        private int _count;


        public Collections()
        {
            // TODO: Initialize internal array with default capacity
        }

        public int Count => _count;

        public int Capacity => _items.Length;

        public T this[int index]
        {
            get
            {
                // TODO: Return item at index with bounds checking
                throw new NotImplementedException();
            }
            set
            {
                // TODO: Set item at index with bounds checking
                throw new NotImplementedException();
            }
        }

        public void Add(T item)
        {
            // TODO: Add item, resize if needed
            throw new NotImplementedException();
        }

        public void Insert(int index, T item)
        {
            // TODO: Insert item at specified index
            throw new NotImplementedException();
        }

        public bool Remove(T item)
        {
            // TODO: Remove first occurrence of item
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            // TODO: Remove item at specified index
            throw new NotImplementedException();
        }

        public void Clear()
        {
            // TODO: Clear the list
            throw new NotImplementedException();
        }

        public bool Contains(T item)
        {
            // TODO: Return true if item exists
            throw new NotImplementedException();
        }

        public int IndexOf(T item)
        {
            // TODO: Return index of item if found
            throw new NotImplementedException();
        }

        public void EnsureCapacity(int min)
        {
            // TODO: Resize internal array if less than min
            throw new NotImplementedException();
        }

        public T[] ToArray()
        {
            // TODO: Return array copy of items
            throw new NotImplementedException();
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            // TODO: Copy internal items to array
            throw new NotImplementedException();
        }

        public IEnumerator<T> GetEnumerator()
        {
            // TODO: Return enumerator for items
            throw new NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        public void Should_Demonstrate_Difference_Between_IEnumerable_And_IEnumerator()
        {
            //Implement both IEnumerable<T> and IEnumerator<T>
            //Iterate using both foreach and manual .MoveNext()
            //Print and compare outputs
            //Do it all in one method only
        }
        // 🔹 List<T>
        public List<int> CreateIntegerList()
        {
            // TODO: Add at least 3 integers and return the list
            throw new NotImplementedException();
        }

        public int GetSecondItemFromList(List<int> numbers)
        {
            // TODO: Return the second item
            throw new NotImplementedException();
        }

        public List<string> RemoveItemFromList(List<string> items, string itemToRemove)
        {
            // TODO: Remove item from list and return updated list
            throw new NotImplementedException();
        }

        // 🔹 Dictionary<TKey, TValue>
        public Dictionary<string, int> CreateStudentAgeDictionary()
        {
            // TODO: Add at least 3 students with their ages
            throw new NotImplementedException();
        }

        public bool ContainsStudent(Dictionary<string, int> students, string name)
        {
            // TODO: Return true if the dictionary contains the student
            throw new NotImplementedException();
        }

        public int GetStudentAge(Dictionary<string, int> students, string name)
        {
            // TODO: Return the age of the given student
            throw new NotImplementedException();
        }

        // 🔹 HashSet<T>
        public HashSet<string> CreateUniqueNamesSet()
        {
            // TODO: Add names, including duplicates, and return unique set
            throw new NotImplementedException();
        }

        public bool AddToHashSet(HashSet<string> names, string newName)
        {
            // TODO: Try to add and return true if added, false if duplicate
            throw new NotImplementedException();
        }

        // 🔹 Queue<T>
        public Queue<string> CreatePrintQueue()
        {
            // TODO: Add 3 print job names to the queue
            throw new NotImplementedException();
        }

        public string DequeuePrintJob(Queue<string> queue)
        {
            // TODO: Remove and return the first job
            throw new NotImplementedException();
        }

        public string PeekNextPrintJob(Queue<string> queue)
        {
            // TODO: Return the next job without removing
            throw new NotImplementedException();
        }

        // 🔹 Stack<T>
        public Stack<string> CreateUndoStack()
        {
            // TODO: Push 3 operations onto the stack
            throw new NotImplementedException();
        }

        public string PopUndo(Stack<string> stack)
        {
            // TODO: Pop and return the most recent operation
            throw new NotImplementedException();
        }

        public string PeekUndo(Stack<string> stack)
        {
            // TODO: Return the top item without popping
            throw new NotImplementedException();
        }

        // 🔹 LinkedList<T>
        public LinkedList<string> CreateTaskChain()
        {
            // TODO: Add 3 tasks to the linked list
            throw new NotImplementedException();
        }

        public string GetFirstTask(LinkedList<string> taskChain)
        {
            // TODO: Return the first task
            throw new NotImplementedException();
        }

        public string GetLastTask(LinkedList<string> taskChain)
        {
            // TODO: Return the last task
            throw new NotImplementedException();
        }

        // 🔹 ObservableCollection<T>
        public ObservableCollection<string> CreateObservableItemList()
        {
            // TODO: Add 3 items to observable collection
            throw new NotImplementedException();
        }

        public void AddItemToObservableList(ObservableCollection<string> items, string newItem)
        {
            // TODO: Add newItem to the collection
            throw new NotImplementedException();
        }

        // 🔹 ConcurrentDictionary<TKey, TValue>
        public ConcurrentDictionary<int, string> CreateThreadSafeDictionary()
        {
            // TODO: Add 3 items to a concurrent dictionary
            throw new NotImplementedException();
        }

        public bool TryGetValueFromConcurrentDictionary(ConcurrentDictionary<int, string> dict, int key, out string value)
        {
            // TODO: Return true/false if key exists; assign value
            throw new NotImplementedException();
        }
    }
}
