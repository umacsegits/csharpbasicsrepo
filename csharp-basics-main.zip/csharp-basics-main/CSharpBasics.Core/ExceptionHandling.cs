﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics.Core
{
    public class ExceptionHandling
    {
        // Task 1: Handle divide by zero exception
        public static void DivideNumbers(int a, int b)
        {
            // TODO: Try dividing 'a' by 'b'
            // TODO: Catch DivideByZeroException and print a custom error message
        }

        // Task 2: Handle format exception during string to int conversion
        public static void ConvertToInt(string input)
        {
            // TODO: Try parsing the input string to an integer
            // TODO: Catch FormatException and display an appropriate message
        }

        // Task 3: Handle index out of range exception
        public static void AccessArrayElement(int index)
        {
            // TODO: Declare an integer array with 3 elements
            // TODO: Try accessing an element at the given index
            // TODO: Catch IndexOutOfRangeException and print a user-friendly message
        }

        // Task 4: Handle null reference exception
        public static void PrintStringLength(string input)
        {
            // TODO: Try printing the Length of the input string
            // TODO: Catch NullReferenceException and print a warning
        }

        // Task 5: Demonstrate finally block
        public static void FileOperationSim()
        {
            // TODO: Simulate a file operation using a try block
            // TODO: Forcefully throw a general exception
            // TODO: Use a catch block to handle it
            // TODO: Add a finally block to simulate cleanup
        }

        // Task 6: Custom exception handling for age validation
        public static void CheckAge(int age)
        {
            // TODO: If age < 18, throw ArgumentException
            // TODO: Catch and print custom error message
        }

        // Task 7: Demonstrate multiple try blocks and multiple catch blocks
        public static void MultipleTryCatchExample()
        {
            // TODO: First try block: access invalid array index
            // TODO: Second try block: parse invalid number
            // TODO: Third try block: use multiple catch blocks to handle:
            //        - DivideByZeroException
            //        - FormatException
            //        - General Exception
            // TODO: Use Console.ReadLine() in third block for user input
        }

        // Task 8a: Using 'throw ex' — resets stack trace
        public static void ThrowExVersion()
        {
            // TODO: Call ThrowExceptionSource() inside try
            // TODO: Catch and rethrow using 'throw ex;'
        }

        // Task 8b: Using 'throw' — preserves stack trace
        public static void ThrowVersion()
        {
            // TODO: Call ThrowExceptionSource() inside try
            // TODO: Catch and rethrow using 'throw;'
        }

        // Helper method to simulate an original exception
        private static void ThrowExceptionSource()
        {
            // DO NOT MODIFY
            throw new InvalidOperationException("Original source exception.");
        }
    }
}
