﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics.Core
{
    public class FormattingParsing
    {
        // Task 1: Demonstrate C++ style casting (explicit and implicit casting)
        public static void CppStyleCasting()
        {
            // TODO: Declare a double value
            // TODO: Cast it to an int explicitly
            // TODO: Declare an int and assign it to a double (implicit casting)
            // TODO: Print the results of both casts
        }

        // Task 2: Demonstrate int.Parse()
        public static void ParseInteger()
        {
            // TODO: Declare a valid string number (e.g., "123")
            // TODO: Use int.Parse to convert it to an integer
            // TODO: Print the result
            // TODO: Also try parsing an invalid string (e.g., "abc") and catch FormatException
        }

        // Task 3: Demonstrate int.TryParse()
        public static void TryParseInteger()
        {
            // TODO: Declare a string input
            // TODO: Use int.TryParse to attempt conversion
            // TODO: Print whether conversion was successful and the result
        }

        // Task 4: Demonstrate Convert class
        public static void ConvertClassExamples()
        {
            // TODO: Declare a string "456" and use Convert.ToInt32()
            // TODO: Declare a bool and use Convert.ToString(), Convert.ToInt32()
            // TODO: Print all conversions
            // TODO: Catch exceptions like FormatException and InvalidCastException
        }

        // Task 5: Demonstrate Boxing and Unboxing
        public static void BoxingUnboxingExample()
        {
            // TODO: Box an int value into an object
            // TODO: Unbox it back to int
            // TODO: Try invalid unboxing (e.g., unbox as string) and catch InvalidCastException
        }
    }
}
