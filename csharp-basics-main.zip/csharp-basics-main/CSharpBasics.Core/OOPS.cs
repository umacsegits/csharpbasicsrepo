﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics.Core
{
    internal class OOPS
    {
    }
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        // TODO: Implement a default constructor

        // TODO: Implement a parameterized constructor that accepts name and age

        // TODO: Implement a static factory method named Create which returns a new Person object

        /// <summary>
        /// Demonstrates various types of object creation:
        /// 1. Default constructor
        /// 2. Parameterized constructor
        /// 3. Object initializer
        /// 4. Factory method
        /// 5. Activator.CreateInstance
        /// </summary>
        /// <returns>A list of Person objects created using different approaches</returns>
        public static List<Person> DemonstrateObjectCreation()
        {
            var people = new List<Person>();
            // TODO: Create object using default constructor and set properties
            // TODO: Create object using parameterized constructor
            // TODO: Create object using object initializer
            // TODO: Create object using factory method
            // TODO: Create object using Activator.CreateInstance

            // TODO: Return the list of created Person objects
            return people;
        }
    }


}
