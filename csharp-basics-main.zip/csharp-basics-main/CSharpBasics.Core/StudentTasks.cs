using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

namespace CSharpBasics.Core
{
    public class StudentTasks
    {
        // 1. Introduction to C# and .NET
        public static string GetDotNetVersion()
        {
            // TODO: Return the .NET version string (e.g., ".NET 6.0")
            throw new NotImplementedException();
        }

        // 2. .NET Framework Fundamentals
        public static string GetDotNetRuntimeName()
        {
            // TODO: Return the name of the current runtime (e.g., ".NET Core")
            throw new NotImplementedException();
        }

        // 3. C# Syntax and Data Types
        public static int ReturnAnInteger()
        {
            // TODO: Return an integer value (expected: 42)
            throw new NotImplementedException();
        }

        // 4. Methods in Detail
        public static int Add(int a, int b)
        {
            // TODO: Return the sum of a and b
            throw new NotImplementedException();
        }

        // 5. Booleans and Logical Operators
        public static bool IsEligible(int age)
        {
            // TODO: Return true if age is 18 or more, otherwise false
            throw new NotImplementedException();
        }

        // 6. Control Flow in C#
        public static string GetGrade(int score)
        {
            // TODO: Return "A" for 90+, "F" for below 50, etc.
            throw new NotImplementedException();
        }

        // 7. Exception Handling, Logging, Debugging
        public static string SafeDivide(int a, int b)
        {
            // TODO: Return result as string or "Cannot divide by zero"
            throw new NotImplementedException();
        }

        // 8. Arrays
        public static int FindMax(int[] numbers)
        {
            // TODO: Return the maximum number in the array
            throw new NotImplementedException();
        }

        // 9. Formatting and Parsing
        public static double ParseToDouble(string input)
        {
            // TODO: Convert input string to double
            throw new NotImplementedException();
        }

        // 10. Collections
        public static List<string> CreateNamesList()
        {
            // TODO: Return a list containing names including "Alice"
            throw new NotImplementedException();
        }

        // 11. Enums
        public enum WeekDays
        {
            Monday = 1,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday
        }

        // 12. File Handling and I/O
        public static void WriteToFile(string path, string content)
        {
            // TODO: Write content to the specified file
            throw new NotImplementedException();
        }

        public static string ReadFromFile(string path)
        {
            // TODO: Read and return content from the specified file
            throw new NotImplementedException();
        }
    }
}
