﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBasics.Core
{
    public class CSharpMethods
    {
        // Task 1: Regular method (void, no parameters)
        public void Greet()
        {
            // TODO: Print a welcome message to the user
        }

        // Task 2: Static method
        public static void ShowDate()
        {
            // TODO: Print the current date
        }

        // Task 3: Instance method
        public int Multiply(int x, int y)
        {
            // TODO: Return the product of x and y
            return 0; // placeholder
        }

        // Task 4: Method with parameters
        public void DisplayMessage(string name)
        {
            // TODO: Print a message using the given name
        }

        // Task 5: Method with return value
        public double CalculateArea(double radius)
        {
            // TODO: Return the area of a circle (πr²)
            return 0; // placeholder
        }

        // Task 6: Method with optional parameter
        public void PrintReport(string title = "Untitled Report")
        {
            // TODO: Print the title of the report
        }

        // Task 7: Method using ref and out parameters
        public void CalculateSquare(int input, ref int square, out int cube)
        {
            // TODO: Set square using ref
            // TODO: Set cube using out
            square = 0; // placeholder
            cube = 0;   // placeholder
        }

        // Task 8: Method using params keyword
        public int SumNumbers(params int[] numbers)
        {
            // TODO: Return the sum of all numbers passed
            return 0; // placeholder
        }

        // Task 9: Method overloading
        public void DisplayInfo(string name)
        {
            // TODO: Print name only
        }

        public void DisplayInfo(string name, int age)
        {
            // TODO: Print name and age
        }
    }
}
