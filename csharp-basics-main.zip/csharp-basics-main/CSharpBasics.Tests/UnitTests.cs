﻿using Xunit;
using CSharpBasics.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Collections.Concurrent;
using System.Collections.ObjectModel;

namespace CSharpBasics.Tests
{
    public class UnitTests
    {
        [Fact]
        public void Test_IntroductionToCSharpAndDotNet_Version()
        {
            var version = StudentTasks.GetDotNetVersion();
            Assert.StartsWith(".NET", version);
        }

        [Fact]
        public void Test_DotNetFrameworkFundamentals_Runtime()
        {
            var runtime = StudentTasks.GetDotNetRuntimeName();
            Assert.Contains("Core", runtime);
        }

        [Fact]
        public void Test_CSharpSyntaxAndDataTypes_ReturnInteger()
        {
            var result = StudentTasks.ReturnAnInteger();
            Assert.Equal(42, result);
        }

        [Fact]
        public void Test_MethodsInDetail_Addition()
        {
            var result = StudentTasks.Add(3, 4);
            Assert.Equal(7, result);
        }

        [Fact]
        public void Test_BooleansAndLogicalOperators_CheckAge()
        {
            Assert.True(StudentTasks.IsEligible(18));
            Assert.False(StudentTasks.IsEligible(15));
        }

        [Fact]
        public void Test_ControlFlowInCSharp_GetGrade()
        {
            Assert.Equal("A", StudentTasks.GetGrade(90));
            Assert.Equal("F", StudentTasks.GetGrade(40));
        }

        [Fact]
        public void Test_ExceptionHandling_HandleDivideByZero()
        {
            var result = StudentTasks.SafeDivide(10, 0);
            Assert.Equal("Cannot divide by zero", result);
        }

        [Fact]
        public void Test_Arrays_FindMax()
        {
            int[] numbers = { 1, 3, 9, 4 };
            Assert.Equal(9, StudentTasks.FindMax(numbers));
        }

        [Fact]
        public void Test_FormattingAndParsing_ParseDouble()
        {
            Assert.Equal(123.45, StudentTasks.ParseToDouble("123.45"));
        }

        [Fact]
        public void Test_Collections_ListContains()
        {
            var list = StudentTasks.CreateNamesList();
            Assert.Contains("Alice", list);
        }

        [Fact]
        public void Test_FileHandling_WriteAndRead()
        {
            string filePath = "testfile.txt";
            StudentTasks.WriteToFile(filePath, "Hello");
            var content = StudentTasks.ReadFromFile(filePath);
            Assert.Equal("Hello", content);
            File.Delete(filePath);
        }
        #region "Methods & Parameters"
        private readonly CSharpMethods _methods = new CSharpMethods();

        [Fact]
        public void Greet_ShouldNotThrowException()
        {
            var exception = Record.Exception(() => _methods.Greet());
            Assert.Null(exception);
        }

        [Fact]
        public void ShowDate_ShouldNotThrowException()
        {
            var exception = Record.Exception(() => CSharpMethods.ShowDate());
            Assert.Null(exception);
        }

        [Fact]
        public void Multiply_ShouldReturn_CorrectProduct()
        {
            int result = _methods.Multiply(2, 3);
            Assert.Equal(6, result); // Update if student hasn't implemented it yet
        }

        [Fact]
        public void DisplayMessage_ShouldNotThrow()
        {
            var exception = Record.Exception(() => _methods.DisplayMessage("Alice"));
            Assert.Null(exception);
        }

        [Fact]
        public void CalculateArea_ShouldReturn_AreaOfCircle()
        {
            double result = _methods.CalculateArea(2);
            Assert.True(result >= 0); // Looser check for incomplete placeholder
        }

        [Fact]
        public void PrintReport_WithAndWithoutTitle_ShouldNotThrow()
        {
            Assert.Null(Record.Exception(() => _methods.PrintReport()));
            Assert.Null(Record.Exception(() => _methods.PrintReport("Student Report")));
        }

        [Fact]
        public void CalculateSquare_ShouldSetValuesUsingRefAndOut()
        {
            int square = 0;
            int cube;
            _methods.CalculateSquare(3, ref square, out cube);

            Assert.True(square >= 0);
            Assert.True(cube >= 0);
        }

        [Fact]
        public void SumNumbers_ShouldReturn_CorrectSum()
        {
            int result = _methods.SumNumbers(1, 2, 3, 4);
            Assert.Equal(10, result); // Placeholder
        }

        [Fact]
        public void DisplayInfo_ShouldSupport_Overloading()
        {
            Assert.Null(Record.Exception(() => _methods.DisplayInfo("Bob")));
            Assert.Null(Record.Exception(() => _methods.DisplayInfo("Bob", 25)));
        }
        #endregion
        #region "FormattingParsingTests"
        [Fact]
        public void CppStyleCasting_ShouldDemonstrate_ImplicitAndExplicitCasting()
        {
            var exception = Record.Exception(() => FormattingParsing.CppStyleCasting());
            Assert.Null(exception);
        }

        [Fact]
        public void ParseInteger_ShouldCatch_FormatException_ForInvalidString()
        {
            var exception = Record.Exception(() => FormattingParsing.ParseInteger());
            Assert.Null(exception);
        }

        [Fact]
        public void TryParseInteger_ShouldHandle_InvalidInput_Gracefully()
        {
            var exception = Record.Exception(() => FormattingParsing.TryParseInteger());
            Assert.Null(exception);
        }

        [Fact]
        public void ConvertClassExamples_ShouldHandleConversions()
        {
            var exception = Record.Exception(() => FormattingParsing.ConvertClassExamples());
            Assert.Null(exception);
        }

        [Fact]
        public void BoxingUnboxingExample_ShouldDemonstrateBoxingAndUnboxing()
        {
            var exception = Record.Exception(() => FormattingParsing.BoxingUnboxingExample());
            Assert.Null(exception);
        }
        #endregion
        #region ExceptionHandling
        [Fact]
        public void DivideNumbers_ShouldCatch_DivideByZeroException()
        {
            var exception = Record.Exception(() => ExceptionHandling.DivideNumbers(10, 0));
            Assert.Null(exception);
        }

        [Fact]
        public void ConvertToInt_ShouldCatch_FormatException()
        {
            var exception = Record.Exception(() => ExceptionHandling.ConvertToInt("NotANumber"));
            Assert.Null(exception);
        }

        [Fact]
        public void AccessArrayElement_ShouldCatch_IndexOutOfRangeException()
        {
            var exception = Record.Exception(() => ExceptionHandling.AccessArrayElement(100));
            Assert.Null(exception);
        }

        [Fact]
        public void PrintStringLength_ShouldCatch_NullReferenceException()
        {
            var exception = Record.Exception(() => ExceptionHandling.PrintStringLength(null));
            Assert.Null(exception);
        }

        [Fact]
        public void FileOperationSim_ShouldExecute_FinallyBlock()
        {
            var exception = Record.Exception(() => ExceptionHandling.FileOperationSim());
            Assert.Null(exception);
        }

        [Theory]
        [InlineData(17)]
        [InlineData(-5)]
        public void CheckAge_ShouldCatch_ArgumentException(int invalidAge)
        {
            var exception = Record.Exception(() => ExceptionHandling.CheckAge(invalidAge));
            Assert.Null(exception);
        }

        [Fact]
        public void CheckAge_ShouldAccept_ValidAge()
        {
            var exception = Record.Exception(() => ExceptionHandling.CheckAge(25));
            Assert.Null(exception);
        }

        [Fact]
        public void MultipleTryCatchExample_ShouldHandle_AllExceptions()
        {
            var exception = Record.Exception(() => ExceptionHandling.MultipleTryCatchExample());
            Assert.Null(exception);
        }

        [Fact]
        public void ThrowExVersion_ShouldResetStackTrace()
        {
            var ex = Assert.Throws<InvalidOperationException>(() => ExceptionHandling.ThrowExVersion());

            Assert.Contains("ThrowExVersion", ex.StackTrace);
            Assert.DoesNotContain("ThrowExceptionSource", ex.StackTrace);
        }

        [Fact]
        public void ThrowVersion_ShouldPreserveStackTrace()
        {
            var ex = Assert.Throws<InvalidOperationException>(() => ExceptionHandling.ThrowVersion());

            Assert.Contains("ThrowExceptionSource", ex.StackTrace);
            Assert.Contains("ThrowVersion", ex.StackTrace);
        }
        #endregion
        #region OOPS
        [Fact]
        public void DemonstrateObjectCreation_ShouldCreateFivePersons()
        {
            var result = Person.DemonstrateObjectCreation();

            Assert.NotNull(result);
            Assert.Equal(5, result.Count);

            Assert.Equal("Alice", result[0].Name);
            Assert.Equal(30, result[0].Age);

            Assert.Equal("Bob", result[1].Name);
            Assert.Equal(25, result[1].Age);

            Assert.Equal("Charlie", result[2].Name);
            Assert.Equal(22, result[2].Age);

            Assert.Equal("Daisy", result[3].Name);
            Assert.Equal(28, result[3].Age);

            Assert.Equal("Eve", result[4].Name);
            Assert.Equal(26, result[4].Age);
        }
        #endregion
        #region Collections
        private readonly Collections<int> _intCustomList = new Collections<int>();
        private readonly Collections<string> _stringCustomList = new Collections<string>();

        // 🔹 List<T>
        [Fact]
        public void CreateIntegerList_ShouldReturnListWith3Items()
        {
            var list = _intCustomList.CreateIntegerList();
            Assert.Equal(3, list.Count);
        }

        [Fact]
        public void GetSecondItemFromList_ShouldReturnSecondElement()
        {
            var result = _intCustomList.GetSecondItemFromList(new List<int> { 1, 2, 3 });
            Assert.Equal(2, result);
        }

        [Fact]
        public void RemoveItemFromList_ShouldRemoveSpecificItem()
        {
            var list = new List<string> { "A", "B", "C" };
            var updated = _stringCustomList.RemoveItemFromList(list, "B");
            Assert.Equal(2, updated.Count);
            Assert.DoesNotContain("B", updated);
        }

        // 🔹 Dictionary<TKey, TValue>
        [Fact]
        public void CreateStudentAgeDictionary_ShouldContainThreeStudents()
        {
            var dict = _stringCustomList.CreateStudentAgeDictionary();
            Assert.Equal(3, dict.Count);
        }

        [Fact]
        public void ContainsStudent_ShouldReturnTrueIfStudentExists()
        {
            var dict = new Dictionary<string, int> { { "John", 22 } };
            var exists = _stringCustomList.ContainsStudent(dict, "John");
            Assert.True(exists);
        }

        [Fact]
        public void GetStudentAge_ShouldReturnCorrectAge()
        {
            var dict = new Dictionary<string, int> { { "Alice", 30 } };
            var age = _stringCustomList.GetStudentAge(dict, "Alice");
            Assert.Equal(30, age);
        }

        // 🔹 HashSet<T>
        [Fact]
        public void CreateUniqueNamesSet_ShouldReturnUniqueItems()
        {
            var set = _stringCustomList.CreateUniqueNamesSet();
            Assert.Equal(set.Count, new HashSet<string>(set).Count);
        }

        [Fact]
        public void AddToHashSet_ShouldAddIfNotExists()
        {
            var set = new HashSet<string> { "Apple" };
            var added = _stringCustomList.AddToHashSet(set, "Banana");
            Assert.True(added);
            Assert.Contains("Banana", set);
        }

        // 🔹 Queue<T>
        [Fact]
        public void CreatePrintQueue_ShouldContain3Items()
        {
            var queue = _stringCustomList.CreatePrintQueue();
            Assert.Equal(3, queue.Count);
        }

        [Fact]
        public void DequeuePrintJob_ShouldReturnFirstItem()
        {
            var queue = new Queue<string>(new[] { "Doc1", "Doc2" });
            var job = _stringCustomList.DequeuePrintJob(queue);
            Assert.Equal("Doc1", job);
            Assert.Single(queue);
        }

        [Fact]
        public void PeekNextPrintJob_ShouldReturnNextWithoutRemoving()
        {
            var queue = new Queue<string>(new[] { "Job1", "Job2" });
            var job = _stringCustomList.PeekNextPrintJob(queue);
            Assert.Equal("Job1", job);
            Assert.Equal(2, queue.Count);
        }

        // 🔹 Stack<T>
        [Fact]
        public void CreateUndoStack_ShouldReturnStackWith3Items()
        {
            var stack = _stringCustomList.CreateUndoStack();
            Assert.Equal(3, stack.Count);
        }

        [Fact]
        public void PopUndo_ShouldRemoveTopItem()
        {
            var stack = new Stack<string>(new[] { "1st", "2nd" });
            var result = _stringCustomList.PopUndo(stack);
            Assert.Equal("2nd", result);
            Assert.Single(stack);
        }

        [Fact]
        public void PeekUndo_ShouldReturnTopItem()
        {
            var stack = new Stack<string>(new[] { "First", "Second" });
            var result = _stringCustomList.PeekUndo(stack);
            Assert.Equal("Second", result);
            Assert.Equal(2, stack.Count);
        }

        // 🔹 LinkedList<T>
        [Fact]
        public void CreateTaskChain_ShouldReturn3Items()
        {
            var tasks = _stringCustomList.CreateTaskChain();
            Assert.Equal(3, tasks.Count);
        }

        [Fact]
        public void GetFirstTask_ShouldReturnFirstNodeValue()
        {
            var list = new LinkedList<string>(new[] { "T1", "T2" });
            var result = _stringCustomList.GetFirstTask(list);
            Assert.Equal("T1", result);
        }

        [Fact]
        public void GetLastTask_ShouldReturnLastNodeValue()
        {
            var list = new LinkedList<string>(new[] { "T1", "T2" });
            var result = _stringCustomList.GetLastTask(list);
            Assert.Equal("T2", result);
        }

        // 🔹 ObservableCollection<T>
        [Fact]
        public void CreateObservableItemList_ShouldReturn3Items()
        {
            var items = _stringCustomList.CreateObservableItemList();
            Assert.Equal(3, items.Count);
        }

        [Fact]
        public void AddItemToObservableList_ShouldAddItem()
        {
            var obs = new ObservableCollection<string> { "One", "Two" };
            _stringCustomList.AddItemToObservableList(obs, "Three");
            Assert.Equal(3, obs.Count);
            Assert.Contains("Three", obs);
        }

        // 🔹 ConcurrentDictionary<TKey, TValue>
        [Fact]
        public void CreateThreadSafeDictionary_ShouldContain3Items()
        {
            var dict = _intCustomList.CreateThreadSafeDictionary();
            Assert.Equal(3, dict.Count);
        }

        [Fact]
        public void TryGetValueFromConcurrentDictionary_ShouldReturnTrueAndCorrectValue()
        {
            var dict = new ConcurrentDictionary<int, string>();
            dict[100] = "Test";
            var result = _intCustomList.TryGetValueFromConcurrentDictionary(dict, 100, out string value);
            Assert.True(result);
            Assert.Equal("Test", value);
        }
        [Fact]
        public void Add_ShouldIncreaseCount()
        {
            var list = new Collections<int>();
            list.Add(10);
            list.Add(20);
            Assert.Equal(2, list.Count);
        }

        [Fact]
        public void Indexer_Get_ShouldReturnCorrectElement()
        {
            var list = new Collections<string>();
            list.Add("A");
            list.Add("B");
            Assert.Equal("B", list[1]);
        }

        [Fact]
        public void Indexer_Set_ShouldUpdateElement()
        {
            var list = new Collections<string>();
            list.Add("X");
            list[0] = "Y";
            Assert.Equal("Y", list[0]);
        }

        [Fact]
        public void Insert_ShouldInsertAtCorrectIndex()
        {
            var list = new Collections<string>();
            list.Add("A");
            list.Add("C");
            list.Insert(1, "B");
            Assert.Equal("B", list[1]);
            Assert.Equal(3, list.Count);
        }

        [Fact]
        public void Remove_ShouldRemoveItem()
        {
            var list = new Collections<int>();
            list.Add(10);
            list.Add(20);
            var removed = list.Remove(10);
            Assert.True(removed);
            Assert.False(list.Contains(10));
        }

        [Fact]
        public void RemoveAt_ShouldRemoveItemAtIndex()
        {
            var list = new Collections<string>();
            list.Add("A");
            list.Add("B");
            list.RemoveAt(0);
            Assert.Equal("B", list[0]);
            Assert.Equal(1, list.Count);
        }

        [Fact]
        public void Clear_ShouldResetCountToZero()
        {
            var list = new Collections<int>();
            list.Add(1);
            list.Add(2);
            list.Clear();
            Assert.Equal(0, list.Count);
        }

        [Fact]
        public void Contains_ShouldReturnTrue_IfExists()
        {
            var list = new Collections<int>();
            list.Add(5);
            Assert.True(list.Contains(5));
        }

        [Fact]
        public void Contains_ShouldReturnFalse_IfNotExists()
        {
            var list = new Collections<string>();
            list.Add("X");
            Assert.False(list.Contains("Y"));
        }

        [Fact]
        public void IndexOf_ShouldReturnCorrectIndex()
        {
            var list = new Collections<string>();
            list.Add("One");
            list.Add("Two");
            Assert.Equal(1, list.IndexOf("Two"));
        }

        [Fact]
        public void EnsureCapacity_ShouldNotThrow()
        {
            var list = new Collections<int>();
            list.EnsureCapacity(100);
            Assert.True(list.Capacity >= 100);
        }

        [Fact]
        public void ToArray_ShouldReturnAccurateArray()
        {
            var list = new Collections<string>();
            list.Add("A");
            list.Add("B");
            var arr = list.ToArray();
            Assert.Equal(new[] { "A", "B" }, arr);
        }

        [Fact]
        public void CopyTo_ShouldCopyElements()
        {
            var list = new Collections<int>();
            list.Add(1);
            list.Add(2);
            var array = new int[5];
            list.CopyTo(array, 2);
            Assert.Equal(1, array[2]);
            Assert.Equal(2, array[3]);
        }

        [Fact]
        public void Enumerator_ShouldIterateOverItems()
        {
            var list = new Collections<string>();
            list.Add("X");
            list.Add("Y");
            int count = 0;
            foreach (var item in list)
            {
                Assert.True(item == "X" || item == "Y");
                count++;
            }
            Assert.Equal(2, count);
        }

        [Fact]
        public void AccessingInvalidIndex_ShouldThrowException()
        {
            var list = new Collections<int>();
            list.Add(1);
            Assert.Throws<IndexOutOfRangeException>(() => list[5]);
        }

        [Fact]
        public void Insert_InvalidIndex_ShouldThrowException()
        {
            var list = new Collections<int>();
            Assert.Throws<ArgumentOutOfRangeException>(() => list.Insert(10, 5));
        }

        [Fact]
        public void RemoveAt_InvalidIndex_ShouldThrowException()
        {
            var list = new Collections<string>();
            list.Add("Test");
            Assert.Throws<ArgumentOutOfRangeException>(() => list.RemoveAt(2));
        }
        #endregion
    }
}