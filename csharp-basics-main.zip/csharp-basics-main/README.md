﻿## 📘 C# Fundamentals Practice – Student Exercises

This project is designed for students and beginners to **learn and practice the fundamentals of C# and .NET** through guided exercises and structured templates. Each section is broken into focused topics, helping learners gradually master core concepts.

---

## 📂 Project Structure and Learning Modules

### ✅ `StudentTasks.cs`

**Goal**: Understand foundational C# and .NET concepts.

| Task # | Topic                       | Description                                             |
| ------ | --------------------------- | ------------------------------------------------------- |
| 1      | Introduction to C# and .NET | Return the current .NET version string.                 |
| 2      | .NET Runtime Fundamentals   | Identify the .NET runtime name in use.                  |
| 3      | C# Syntax & Data Types      | Return a sample integer value (e.g., 42).               |
| 4      | Methods in C#               | Write a method to return the sum of two numbers.        |
| 5      | Booleans & Logic            | Return eligibility based on age.                        |
| 6      | Control Flow                | Map score to grade (A, B, C, etc.).                     |
| 7      | Exception Handling          | Handle division by zero and return meaningful messages. |
| 8      | Arrays                      | Find the maximum number in an array.                    |
| 9      | Formatting & Parsing        | Convert a string to a double using parsing.             |
| 10     | Collections                 | Return a list of names containing “Alice”.              |
| 11     | Enums                       | Define and use a `WeekDays` enum.                       |
| 12     | File I/O                    | Read and write strings to and from files.               |

---

### ✅ `Person.cs`

**Goal**: Practice object-oriented programming (OOP) and different object creation methods.

| Task                      | Description                                                 |
| ------------------------- | ----------------------------------------------------------- |
| Default Constructor       | Create a basic person with default values.                  |
| Parameterized Constructor | Allow setting name and age through parameters.              |
| Static Factory Method     | Return a `Person` object using a factory.                   |
| Object Initializer        | Instantiate object using curly braces syntax.               |
| Activator Class           | Use `Activator.CreateInstance` for dynamic object creation. |

> Includes a method to return a `List<Person>` demonstrating all creation styles.

---

### ✅ `FormattingParsing.cs`

**Goal**: Practice casting, parsing, conversions, and boxing/unboxing.

| Task # | Topic             | Description                                              |
| ------ | ----------------- | -------------------------------------------------------- |
| 1      | C++ Style Casting | Demonstrate both implicit and explicit casting.          |
| 2      | `int.Parse()`     | Convert a valid/invalid string to int and handle errors. |
| 3      | `int.TryParse()`  | Safely attempt conversion with `TryParse`.               |
| 4      | `Convert` Class   | Use the `Convert` class for various data conversions.    |
| 5      | Boxing & Unboxing | Demonstrate boxing/unboxing and catch unboxing errors.   |

---

### ✅ `ExceptionHandling.cs`

**Goal**: Learn to handle common runtime exceptions using `try`, `catch`, `finally`, and `throw`.

| Task # | Topic                 | Description                                        |
| ------ | --------------------- | -------------------------------------------------- |
| 1      | Divide by Zero        | Catch divide-by-zero errors.                       |
| 2      | Format Exception      | Handle invalid string-to-int conversions.          |
| 3      | Index Out of Range    | Catch array access beyond bounds.                  |
| 4      | Null Reference        | Safely handle null strings.                        |
| 5      | Finally Block         | Use finally for cleanup regardless of exception.   |
| 6      | Custom Exception      | Throw and catch application-specific errors.       |
| 7      | Multiple Catch Blocks | Handle different exceptions in one try block.      |
| 8      | Throw vs Throw Ex     | Understand the difference in stack trace behavior. |

---

### ✅ `Collections.cs`

**Goal**: Master generic collections and understand common collection types in .NET.

#### Custom Generic Collection

* Implement your own dynamic array-like collection (`Collections<T>`) with basic operations like `Add`, `Remove`, `Clear`, `Contains`, etc.
* Implement `IEnumerable<T>` interface.

#### Collection Types Practice

| Type                                 | Key Tasks                                 |
| ------------------------------------ | ----------------------------------------- |
| `List<T>`                            | Add, access, and remove items.            |
| `Dictionary<TKey, TValue>`           | Key-based lookup and safe retrieval.      |
| `HashSet<T>`                         | Handle unique data.                       |
| `Queue<T>`                           | First-In-First-Out logic.                 |
| `Stack<T>`                           | Last-In-First-Out logic.                  |
| `LinkedList<T>`                      | Forward/backward navigation.              |
| `ObservableCollection<T>`            | Demonstrate dynamic updates.              |
| `ConcurrentDictionary<TKey, TValue>` | Thread-safe data access and manipulation. |

---

### ✅ `Methods.cs` *(sample tasks)*

**Goal**: Learn different types of methods in C#.

| Task | Method Type         | Description                            |
| ---- | ------------------- | -------------------------------------- |
| 1    | Regular Method      | Display a welcome message.             |
| 2    | Static Method       | Show today’s date.                     |
| 3    | Instance Method     | Multiply two integers.                 |
| 4    | With Parameters     | Print a message with a name.           |
| 5    | With Return         | Calculate area of a circle.            |
| 6    | Optional Parameters | Print report title.                    |
| 7    | `ref` and `out`     | Set values using both parameter types. |
| 8    | `params` Keyword    | Sum multiple numbers.                  |
| 9    | Method Overloading  | Show info with 1 or 2 parameters.      |

---

## 🛠 How to Use

1. **Fork** the project.
2. Open in **Visual Studio**.
3. Work on each method marked with `// TODO`.
4. Write your own **unit tests** using **XUnit**.
5. Run and debug your code to understand behavior.

---

## 📚 Learning Outcomes

* Build confidence with **C# syntax** and **.NET runtime**.
* Understand and implement **core programming constructs**.
* Practice **OOP**, **collections**, **file I/O**, and **error handling**.
* Prepare for real-world .NET development and interviews.
 