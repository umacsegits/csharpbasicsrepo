﻿namespace ThreadingAndSyncTask;

public class Job
{
    public int Id { get; set; }
    public string Description { get; set; } = string.Empty;
    public int DurationInMs { get; set; }

    public void Execute()
    {
        // TODO: Simulate job execution using Thread.Sleep
    }
}