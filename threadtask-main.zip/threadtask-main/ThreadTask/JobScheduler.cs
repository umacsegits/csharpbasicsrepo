﻿using System.Collections.Concurrent;

namespace ThreadingAndSyncTask;

public class JobScheduler
{
    private readonly ConcurrentQueue<Job> _jobs = new();
    private readonly object _lock = new();

    public void AddJob(Job job)
    {
        // TODO: Enqueue job in a thread-safe manner
    }

    public void ProcessJobsUsingThreads()
    {
        // TODO: Start new threads to process jobs
        // TODO: Use lock or Monitor to synchronize job execution
    }

    public void ProcessJobsUsingThreadPool()
    {
        // TODO: Use ThreadPool.QueueUserWorkItem to execute jobs
    }
}