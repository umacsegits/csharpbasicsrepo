﻿namespace ThreadingAndSyncTask;

public class SharedLogger
{
    private readonly object _logLock = new();

    public void Log(string message)
    {
        // TODO: Ensure log writes are thread-safe
    }
}