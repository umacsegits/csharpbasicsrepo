using Xunit;
using ThreadingAndSyncTask;

namespace ThreadingAndSyncTask.Tests;

public class JobSchedulerTests
{
    [Fact]
    public void AddJob_ShouldQueueJob()
    {
        var scheduler = new JobScheduler();
        var job = new Job { Id = 1, Description = "Test", DurationInMs = 500 };

        scheduler.AddJob(job);

        // TODO: Assert logic to verify job was queued (reflection or exposed count in real use)
    }

    [Fact]
    public void ProcessJobsUsingThreads_ShouldExecuteAllJobs()
    {
        var scheduler = new JobScheduler();
        for (int i = 0; i < 5; i++)
        {
            scheduler.AddJob(new Job { Id = i, Description = $"Job {i}", DurationInMs = 100 });
        }

        scheduler.ProcessJobsUsingThreads();

        // TODO: Add validation logic to confirm job execution (may use logger or execution flag)
    }

    [Fact]
    public void ProcessJobsUsingThreadPool_ShouldExecuteAllJobs()
    {
        var scheduler = new JobScheduler();
        for (int i = 0; i < 5; i++)
        {
            scheduler.AddJob(new Job { Id = i, Description = $"Job {i}", DurationInMs = 100 });
        }

        scheduler.ProcessJobsUsingThreadPool();

        // TODO: Add validation logic to confirm job execution
    }
}
