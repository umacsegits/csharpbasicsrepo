# Advanced Threading and Synchronization in a Real-Time Job Scheduler

## Task Title
Advanced Real-Time Job Scheduler Using Threads and Synchronization

## Description
You are developing a simplified real-time job scheduler. The system should simulate job execution using multiple threads, utilize the Thread Pool for optimized performance, and ensure thread safety while handling shared resources. Your scheduler should manage a queue of jobs, execute them with simulated delays, and ensure proper thread state transitions and synchronization mechanisms.

## Topics Covered
- Thread creation and lifecycle (Start, Sleep, Join, Abort)
- Thread states
- Thread Pool usage
- Synchronization (lock, Monitor, Mutex)
- Shared resource management

## Objective
Demonstrate an in-depth understanding of thread management, synchronization, and thread pooling in .NET by simulating a multi-threaded job execution system that avoids race conditions and ensures thread-safe operations.

## Instructions
- Fork the repository.
- Complete the logic in the provided boilerplate code.
- Make sure all the unit tests pass.
- Do not change the test code.
- Submit your solution with a pull request or upload as required.