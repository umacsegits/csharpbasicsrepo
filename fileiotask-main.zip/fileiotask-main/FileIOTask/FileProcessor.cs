﻿using System.Text;

namespace FileIOStreamsTask.Services;

public class FileProcessor
{
    public void ProcessFileUsingStreamReader(string inputFilePath, string outputFilePath)
    {
        // TODO: Implement logic using StreamReader and StreamWriter
    }

    public void ProcessFileUsingBufferedStream(string inputFilePath, string outputFilePath)
    {
        // TODO: Implement logic using BufferedStream for byte-level processing
    }

    public void ProcessBinaryFile(string inputFilePath, string outputFilePath)
    {
        // TODO: Implement logic using BinaryReader and BinaryWriter
    }
}