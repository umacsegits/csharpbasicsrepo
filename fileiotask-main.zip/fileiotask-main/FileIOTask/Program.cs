﻿using FileIOStreamsTask.Services;

namespace FileIOStreamsTask;

class Program
{
    static void Main(string[] args)
    {
        // TODO: Create FileProcessor instance and call appropriate methods
        // to demonstrate reading, transforming, and writing large files
    }
}