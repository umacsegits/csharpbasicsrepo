using FileIOStreamsTask.Services;
using Xunit;
using System.IO;

namespace FileIOStreamsTask.Tests;

public class FileProcessorTests
{
    [Fact]
    public void ProcessFileUsingStreamReader_ShouldProcessCorrectly()
    {
        // Arrange
        var processor = new FileProcessor();
        string inputFile = "input.txt";
        string outputFile = "output.txt";
        File.WriteAllLines(inputFile, new[] { "Line 1", "", "Line 2" });

        // Act
        processor.ProcessFileUsingStreamReader(inputFile, outputFile);

        // Assert
        var lines = File.ReadAllLines(outputFile);
        Assert.Equal(2, lines.Length);
        Assert.Equal("Line 1", lines[0]);
        Assert.Equal("Line 2", lines[1]);
    }

    [Fact]
    public void ProcessFileUsingBufferedStream_ShouldProcessBytesCorrectly()
    {
        // Arrange
        var processor = new FileProcessor();
        string inputFile = "input.bin";
        string outputFile = "output.bin";
        File.WriteAllBytes(inputFile, new byte[] { 65, 66, 67 });

        // Act
        processor.ProcessFileUsingBufferedStream(inputFile, outputFile);

        // Assert
        var outputBytes = File.ReadAllBytes(outputFile);
        Assert.NotEmpty(outputBytes);
    }

    [Fact]
    public void ProcessBinaryFile_ShouldCopyBinaryDataCorrectly()
    {
        // Arrange
        var processor = new FileProcessor();
        string inputFile = "binaryInput.dat";
        string outputFile = "binaryOutput.dat";
        using (var bw = new BinaryWriter(File.OpenWrite(inputFile)))
        {
            bw.Write(100);
            bw.Write("Test");
        }

        // Act
        processor.ProcessBinaryFile(inputFile, outputFile);

        // Assert
        using var br = new BinaryReader(File.OpenRead(outputFile));
        Assert.Equal(100, br.ReadInt32());
        Assert.Equal("Test", br.ReadString());
    }
}