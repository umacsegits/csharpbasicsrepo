# File IO Task: Large File Processing with Streams

## Task Title
Efficient File Processing Using Byte and Character Streams

## Description
You're developing a utility tool that reads, processes, and writes large log files in different formats (e.g., plain text, CSV). The tool must use C# file I/O classes efficiently to minimize memory usage and handle both byte and character streams. The system should read a large input file, apply transformations (e.g., remove blank lines, extract specific fields), and write the output to a new file.

## Topics Covered
- FileStream
- StreamReader and StreamWriter
- BufferedStream
- BinaryReader and BinaryWriter
- IDisposable pattern with file streams
- Memory-efficient file handling

## Objective
By completing this task, you will:
- Learn how to read and write large files using byte and character streams in .NET.
- Gain hands-on experience with file I/O classes in different scenarios.
- Implement robust and efficient stream processing code with proper resource management.

## Instructions
- Fork the repository.
- Complete the logic in the provided boilerplate code.
- Make sure all the unit tests pass.
- Do not change the test code.
- Submit your solution with a pull request or upload as required.